﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TugasCalculator
{
    public class Calculator
    {
        public int NilaiA { get; set; }
        public int NilaiB { get; set; }
        public string Hasil { get; set; }

    }
}
