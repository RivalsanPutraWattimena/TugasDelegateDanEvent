# TugasDelegateDanEvent #
- Tugas Pertemuan 8 Mata Kuliah Pemrograman lanjut
- Nama: Rivalsan Putra Wattimena
- Nim: 21.11.4016
